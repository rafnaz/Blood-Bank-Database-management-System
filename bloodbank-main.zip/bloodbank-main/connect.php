<?php
$con=mysqli_connect("localhost","root","","blood");
// mysql_select_db("doctor",$con);
if(!$con){
    die("Can't connect to Database");
}
?>